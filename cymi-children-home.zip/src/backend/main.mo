import Text "mo:core/Text";
import List "mo:core/List";
import Time "mo:core/Time";
import Iter "mo:core/Iter";
import Order "mo:core/Order";
import Array "mo:core/Array";
import Runtime "mo:core/Runtime";

actor {
  type LeadSubmission = {
    id : Text;
    name : Text;
    email : Text;
    company : Text;
    message : Text;
    timestamp : Int;
  };

  module LeadSubmission {
    public func compareByTimestamp(a : LeadSubmission, b : LeadSubmission) : Order.Order {
      Int.compare(a.timestamp, b.timestamp);
    };
  };

  var submissions = List.empty<LeadSubmission>();

  public shared ({ caller }) func submitLead(name : Text, email : Text, company : Text, message : Text) : async () {
    let id = name.concat(email);
    let submission : LeadSubmission = {
      id;
      name;
      email;
      company;
      message;
      timestamp = Time.now();
    };
    submissions.add(submission);
  };

  public query ({ caller }) func getAllSubmissions() : async [LeadSubmission] {
    submissions.values().toArray().sort(LeadSubmission.compareByTimestamp);
  };

  public shared ({ caller }) func deleteSubmission(id : Text) : async () {
    let filteredList = submissions.filter(func(submission) { submission.id != id });
    submissions := filteredList;
  };

  public query ({ caller }) func getSubmission(id : Text) : async LeadSubmission {
    switch (submissions.values().find(func(submission) { submission.id == id })) {
      case (?submission) { submission };
      case (null) { Runtime.trap("Submission not found") };
    };
  };

  public query ({ caller }) func getLeadsByEmail(email : Text) : async [LeadSubmission] {
    let filtered = submissions.values().filter(
      func(submission) { submission.email.contains(#text(email)) }
    );
    filtered.toArray();
  };
};
