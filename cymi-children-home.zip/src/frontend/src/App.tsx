import { Toaster } from "@/components/ui/sonner";
import { useCallback, useState } from "react";
import { AboutSection } from "./components/AboutSection";
import { AdminDashboard } from "./components/AdminDashboard";
import { CampaignsSection } from "./components/CampaignsSection";
import { ContactSection } from "./components/ContactSection";
import { DonationSection } from "./components/DonationSection";
import { Footer } from "./components/Footer";
import { HeroSection } from "./components/HeroSection";
import { ImpactSection } from "./components/ImpactSection";
import { NavBar } from "./components/NavBar";
import { PartnersSection } from "./components/PartnersSection";
import { TestimonialsSection } from "./components/TestimonialsSection";
import { useAdminAuth } from "./hooks/useAdminAuth";

type View = "main" | "admin";

export default function App() {
  const [view, setView] = useState<View>("main");
  const [currentSection, setCurrentSection] = useState("home");
  const [preselectedCampaignId, setPreselectedCampaignId] = useState<
    bigint | undefined
  >(undefined);
  const { isAdmin } = useAdminAuth();

  const scrollToSection = useCallback(
    (sectionId: string) => {
      setCurrentSection(sectionId);
      if (view !== "main") {
        setView("main");
        // Give time for component to render before scrolling
        setTimeout(() => {
          const el = document.getElementById(sectionId);
          if (el) el.scrollIntoView({ behavior: "smooth" });
        }, 100);
      } else {
        const el = document.getElementById(sectionId);
        if (el) el.scrollIntoView({ behavior: "smooth" });
      }
    },
    [view],
  );

  const handleDonateForCampaign = useCallback(
    (campaignId?: bigint) => {
      setPreselectedCampaignId(campaignId);
      scrollToSection("donate");
    },
    [scrollToSection],
  );

  if (view === "admin") {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <AdminDashboard onBack={() => setView("main")} />
        <Toaster
          position="bottom-right"
          toastOptions={{
            style: {
              background: "oklch(100% 0 0)",
              border: "1px solid oklch(90% 0.01 80)",
              color: "oklch(18% 0.025 60)",
            },
          }}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <NavBar
        onNavigate={scrollToSection}
        currentSection={currentSection}
        showAdmin={isAdmin}
        onAdminClick={() => setView("admin")}
      />

      <main>
        <HeroSection
          onDonate={() => scrollToSection("donate")}
          onLearnMore={() => scrollToSection("about")}
        />

        <AboutSection />

        <CampaignsSection onDonate={handleDonateForCampaign} />

        <DonationSection preselectedCampaignId={preselectedCampaignId} />

        <ImpactSection />

        <TestimonialsSection />

        <ContactSection />

        <PartnersSection />
      </main>

      <Footer onNavigate={scrollToSection} />

      <Toaster
        position="bottom-right"
        toastOptions={{
          style: {
            background: "oklch(100% 0 0)",
            border: "1px solid oklch(90% 0.01 80)",
            color: "oklch(18% 0.025 60)",
          },
        }}
      />
    </div>
  );
}
